import java.util.*;

public class RegistroMotocicletas {
    private ArrayList<Motocicleta> lista;

    public RegistroMotocicletas() {
        lista = new ArrayList<>();
        lista.add(new Motocicleta("Yamaha", 150, 3000, "Rojo"));
        lista.add(new Motocicleta("Honda", 200, 3500, "Negro"));
        lista.add(new Motocicleta("Suzuki", 250, 4000, "Azul"));
        lista.add(new Motocicleta("Kawasaki", 300, 5500, "Verde"));
        lista.add(new Motocicleta("Ducati", 600, 9000, "Blanco"));
    }

    public ArrayList<Motocicleta> getLista() {
        return lista;
    }

    public void agregar(Motocicleta m) {
        lista.add(m);
    }

    public Motocicleta buscarPorMarca(String marca) {
        for (Motocicleta m : lista) {
            if (m.getMarca().equalsIgnoreCase(marca)) {
                return m;
            }
        }
        return null;
    }

    public void actualizar(String marca, int nuevoCilindraje, double nuevoPrecio, String nuevoColor) {
        Motocicleta m = buscarPorMarca(marca);
        if (m != null) {
            m.setCilindraje(nuevoCilindraje);
            m.setPrecio(nuevoPrecio);
            m.setColor(nuevoColor);
        }
    }

    public void ordenarPorPrecio() {
        lista.sort(Comparator.comparingDouble(Motocicleta::getPrecio));
    }
}
